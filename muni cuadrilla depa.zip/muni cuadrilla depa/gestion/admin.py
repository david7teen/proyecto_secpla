from django.contrib import admin
from .models import (
    Direccion,
    Departamento,
    TipoIncidencia,
    Encuesta,
    Solicitud,
    Cuadrilla,
    ArchivoAdjunto,
)

# ------------------------------
# CONFIGURACIÓN DE ADMIN
# ------------------------------

@admin.register(Direccion)
class DireccionAdmin(admin.ModelAdmin):
    list_display = ("nombre_direccion", "nombre_encargado", "state", "created")
    search_fields = ("nombre_direccion", "nombre_encargado")
    list_filter = ("state",)
    ordering = ("nombre_direccion",)


@admin.register(Departamento)
class DepartamentoAdmin(admin.ModelAdmin):
    list_display = ("nombre_departamento", "direccion", "nombre_encargado", "state")
    search_fields = ("nombre_departamento", "nombre_encargado")
    list_filter = ("direccion", "state")
    ordering = ("nombre_departamento",)


@admin.register(TipoIncidencia)
class TipoIncidenciaAdmin(admin.ModelAdmin):
    list_display = ("nombre", "departamento", "state")
    search_fields = ("nombre", "descripcion")
    list_filter = ("departamento", "state")
    ordering = ("nombre",)


@admin.register(Encuesta)
class EncuestaAdmin(admin.ModelAdmin):
    list_display = ("titulo", "tipo_incidencia", "estado", "state", "created")
    search_fields = ("titulo", "descripcion", "nombre_vecino")
    list_filter = ("estado", "state", "tipo_incidencia")
    ordering = ("-created",)


@admin.register(Solicitud)
class SolicitudAdmin(admin.ModelAdmin):
    list_display = ("id", "encuesta", "estado", "comuna", "state", "created")
    list_filter = ("estado", "state", "comuna")
    search_fields = ("descripcion",)
    ordering = ("-created",)


@admin.register(Cuadrilla)
class CuadrillaAdmin(admin.ModelAdmin):
    list_display = ("nombre_cuadrilla", "departamento", "solicitud", "state")
    list_filter = ("departamento", "state")
    search_fields = ("nombre_cuadrilla",)
    ordering = ("nombre_cuadrilla",)


@admin.register(ArchivoAdjunto)
class ArchivoAdjuntoAdmin(admin.ModelAdmin):
    list_display = ("id", "solicitud", "tipo", "created")
    list_filter = ("tipo",)
    search_fields = ("tipo",)
    ordering = ("-created",)
