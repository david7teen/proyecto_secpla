from django import forms
from .models import Cuadrilla, Solicitud
from .models import (
    Direccion,
    Departamento,
    TipoIncidencia,
    Encuesta,
    Solicitud,
    Cuadrilla,
    ArchivoAdjunto,
)

# -------------------------------
# FORMULARIOS BASE
# -------------------------------

class DireccionForm(forms.ModelForm):
    class Meta:
        model = Direccion
        fields = ["nombre_direccion", "nombre_encargado", "correo_encargado", "state"]


class DepartamentoForm(forms.ModelForm):
    class Meta:
        model = Departamento
        fields = ["direccion", "nombre_departamento", "nombre_encargado", "correo_encargado", "state"]


class TipoIncidenciaForm(forms.ModelForm):
    class Meta:
        model = TipoIncidencia
        fields = ["departamento", "nombre", "descripcion", "state"]


class EncuestaForm(forms.ModelForm):
    class Meta:
        model = Encuesta
        fields = [
            "titulo",
            "estado",
            "descripcion",
            "nombre_vecino",
            "celular_vecino",
            "correo_vecino",
            "pregunta_sugerida",
            "tipo_incidencia",
            "state",
        ]


class SolicitudForm(forms.ModelForm):
    class Meta:
        model = Solicitud
        fields = ["encuesta", "descripcion", "comuna", "estado", "state"]


class CuadrillaForm(forms.ModelForm):
    class Meta:
        model = Cuadrilla
        fields = ["nombre_cuadrilla", "departamento", "solicitud", "state"]


class ArchivoAdjuntoForm(forms.ModelForm):
    class Meta:
        model = ArchivoAdjunto
        fields = ["solicitud", "tipo", "ruta_archivo"]


class CuadrillaForm(forms.ModelForm):
    class Meta:
        model = Cuadrilla
        fields = ["nombre_cuadrilla", "departamento"]


class AsignarCuadrillaForm(forms.ModelForm):
    class Meta:
        model = Cuadrilla
        fields = ["solicitud"]  # incidencia a asignar

