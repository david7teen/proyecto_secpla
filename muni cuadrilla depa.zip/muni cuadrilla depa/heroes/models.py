from django.db import models

# ==========================
#   MODELO HABILIDAD
# ==========================

class Habilidad(models.Model):
    STATE_CHOICES = [
        ('Activo', 'Activo'),
        ('Inactivo', 'Inactivo'),
    ]

    nombre = models.CharField(max_length=100, unique=True)
    descripcion = models.TextField(blank=True)
    state = models.CharField(
        max_length=20,
        choices=STATE_CHOICES,
        default='Activo'
    )
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Habilidad"
        verbose_name_plural = "Habilidades"
        ordering = ['nombre']

    def __str__(self):
        return self.nombre


# ==========================
#   MODELO HEROE
# ==========================

class Heroe(models.Model):
    STATE_CHOICES = [
        ('Activo', 'Activo'),
        ('Inactivo', 'Inactivo'),
    ]

    habilidad = models.ForeignKey(Habilidad, on_delete=models.CASCADE)
    nombre = models.CharField(max_length=120)
    alias = models.CharField(max_length=120, blank=True)
    edad = models.PositiveIntegerField(null=True, blank=True)
    descripcion = models.TextField(blank=True)
    state = models.CharField(
        max_length=20,
        choices=STATE_CHOICES,
        default='Activo'
    )
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Héroe"
        verbose_name_plural = "Héroes"
        ordering = ['nombre']

    def __str__(self):
        # Muestra "Peter Parker (Spider-Man)" si tiene alias
        return f"{self.nombre} ({self.alias})" if self.alias else self.nombre
