from django.urls import path
from . import views
from .views import (
    main_gestion,
    overview,
    # Direcciones
    direccion_list, direccion_create, direccion_update, direccion_delete, direccion_detail,
    # Departamentos
    departamento_list, departamento_create, departamento_update, departamento_delete, departamento_detail,
    # Tipos de Incidencia
    tipo_list, tipo_create, tipo_update, tipo_delete, tipo_detail,
)

urlpatterns = [
    # Página principal del módulo
    path('main/', main_gestion, name='gestion_main'),

    # Página de resumen general
    path('overview/', overview, name='gestion_overview'),

    # Direcciones (CRUD)
    path('direccion/', direccion_list, name='gestion_direccion_list'),
    path('direccion/nuevo/', direccion_create, name='gestion_direccion_create'),
    path('direccion/<int:pk>/editar/', direccion_update, name='gestion_direccion_update'),
    path('direccion/<int:pk>/eliminar/', direccion_delete, name='gestion_direccion_delete'),
    path('direccion/<int:pk>/', direccion_detail, name='gestion_direccion_detail'),

    # Departamentos (CRUD)
    path('departamento/', departamento_list, name='gestion_departamento_list'),
    path('departamento/nuevo/', departamento_create, name='gestion_departamento_create'),
    path('departamento/<int:pk>/editar/', departamento_update, name='gestion_departamento_update'),
    path('departamento/<int:pk>/eliminar/', departamento_delete, name='gestion_departamento_delete'),
    path('departamento/<int:pk>/', departamento_detail, name='gestion_departamento_detail'),

    # Tipos de Incidencia (CRUD)
    path('tipo/', tipo_list, name='gestion_tipo_list'),
    path('tipo/nuevo/', tipo_create, name='gestion_tipo_create'),
    path('tipo/<int:pk>/editar/', tipo_update, name='gestion_tipo_update'),
    path('tipo/<int:pk>/eliminar/', tipo_delete, name='gestion_tipo_delete'),
    path('tipo/<int:pk>/', tipo_detail, name='gestion_tipo_detail'),

    path("cuadrillas/", views.listar_cuadrillas, name="listar_cuadrillas"),
    path("cuadrillas/nueva/", views.crear_cuadrilla, name="crear_cuadrilla"),
    path("cuadrillas/asignar/<int:id>/", views.asignar_cuadrilla, name="asignar_cuadrilla"),
]