from django.urls import path
from .views import (
    main_habilidad,
    habilidad_list, habilidad_create, habilidad_update, habilidad_delete, habilidad_detail, habilidad_guardar,
    heroe_list, heroe_create, heroe_update, heroe_delete, heroe_detail
)

urlpatterns = [
    # ---------- MENÚ PRINCIPAL ----------
    path('main_habilidad/', main_habilidad, name='heroes_main_habilidad'),

    # ---------- CRUD Habilidad ----------
    # Listado general
    path('habilidad/', habilidad_list, name='heroes_habilidad_list'),

    # Crear nueva habilidad con formulario Django
    path('habilidad/nuevo/', habilidad_create, name='heroes_habilidad_create'),

    # Crear nueva habilidad con formulario HTML básico (Tutorial 4)
    path('habilidad/guardar/', habilidad_guardar, name='habilidad_guardar'),

    # Editar / Eliminar / Detalle
    path('habilidad/<int:pk>/editar/', habilidad_update, name='heroes_habilidad_update'),
    path('habilidad/<int:pk>/eliminar/', habilidad_delete, name='heroes_habilidad_delete'),
    path('habilidad/<int:pk>/', habilidad_detail, name='heroes_habilidad_detail'),

    # ---------- CRUD Héroe ----------
    path('heroe/', heroe_list, name='heroes_heroe_list'),
    path('heroe/nuevo/', heroe_create, name='heroes_heroe_create'),
    path('heroe/<int:pk>/editar/', heroe_update, name='heroes_heroe_update'),
    path('heroe/<int:pk>/eliminar/', heroe_delete, name='heroes_heroe_delete'),
    path('heroe/<int:pk>/', heroe_detail, name='heroes_heroe_detail'),
]
