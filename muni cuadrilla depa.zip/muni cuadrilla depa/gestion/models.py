from django.db import models

# -----------------------------
# Constantes/choices reutilizables
# -----------------------------
ESTADOS = (
    ("Activo", "Activo"),
    ("Inactivo", "Inactivo"),
)


# -----------------------------
# MODELOS
# -----------------------------
class Direccion(models.Model):
    nombre_direccion = models.CharField(max_length=150, unique=True, db_index=True)
    nombre_encargado = models.CharField(max_length=120, blank=True)
    correo_encargado = models.EmailField(blank=True)
    state = models.CharField(max_length=10, choices=ESTADOS, default="Activo")
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["nombre_direccion"]
        verbose_name = "Dirección"
        verbose_name_plural = "Direcciones"

    def __str__(self):
        return self.nombre_direccion


class Departamento(models.Model):
    direccion = models.ForeignKey(
        Direccion, on_delete=models.PROTECT, related_name="departamentos"
    )
    nombre_departamento = models.CharField(max_length=150, db_index=True)
    nombre_encargado = models.CharField(max_length=120, blank=True)
    correo_encargado = models.EmailField(blank=True)
    state = models.CharField(max_length=10, choices=ESTADOS, default="Activo")
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("direccion", "nombre_departamento")
        ordering = ["nombre_departamento"]
        verbose_name = "Departamento"
        verbose_name_plural = "Departamentos"

    def __str__(self):
        return f"{self.nombre_departamento} ({self.direccion})"


class TipoIncidencia(models.Model):
    departamento = models.ForeignKey(
        Departamento, on_delete=models.PROTECT, related_name="tipos_incidencia"
    )
    nombre = models.CharField(max_length=150, db_index=True)
    descripcion = models.TextField(blank=True)
    state = models.CharField(max_length=10, choices=ESTADOS, default="Activo")
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("departamento", "nombre")
        ordering = ["nombre"]
        verbose_name = "Tipo de Incidencia"
        verbose_name_plural = "Tipos de Incidencia"

    def __str__(self):
        return self.nombre


class Encuesta(models.Model):
    titulo = models.CharField(max_length=200, db_index=True)
    estado = models.CharField(max_length=50, default="Borrador")  # Borrador/Activa/Bloqueada
    descripcion = models.TextField(blank=True)

    # Datos del vecino (opcionales)
    nombre_vecino = models.CharField(max_length=120, blank=True)
    celular_vecino = models.CharField(max_length=30, blank=True)
    correo_vecino = models.EmailField(blank=True)

    pregunta_sugerida = models.TextField(blank=True)

    tipo_incidencia = models.ForeignKey(
        TipoIncidencia, on_delete=models.PROTECT, related_name="encuestas"
    )
    state = models.CharField(max_length=10, choices=ESTADOS, default="Activo")
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created"]
        verbose_name = "Encuesta"
        verbose_name_plural = "Encuestas"

    def __str__(self):
        return self.titulo


class Solicitud(models.Model):
    encuesta = models.ForeignKey(
        Encuesta, on_delete=models.PROTECT, related_name="solicitudes"
    )
    descripcion = models.TextField(blank=True)
    comuna = models.CharField(max_length=100, blank=True, db_index=True)
    estado = models.CharField(  # Abierta/Derivada/En proceso/Finalizada/Rechazada
        max_length=50, default="Abierta"
    )
    state = models.CharField(max_length=10, choices=ESTADOS, default="Activo")
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created"]
        verbose_name = "Solicitud"
        verbose_name_plural = "Solicitudes"

    def __str__(self):
        return f"Solicitud {self.id} - {self.estado}"


class Cuadrilla(models.Model):
    nombre_cuadrilla = models.CharField(max_length=150, db_index=True)
    departamento = models.ForeignKey(
        Departamento, on_delete=models.PROTECT, related_name="cuadrillas"
    )
    solicitud = models.ForeignKey(
        Solicitud, on_delete=models.SET_NULL, null=True, blank=True, related_name="cuadrillas"
    )
    state = models.CharField(max_length=10, choices=ESTADOS, default="Activo")
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["nombre_cuadrilla"]
        verbose_name = "Cuadrilla"
        verbose_name_plural = "Cuadrillas"

    def __str__(self):
        return self.nombre_cuadrilla


class ArchivoAdjunto(models.Model):
    solicitud = models.ForeignKey(
        Solicitud, on_delete=models.CASCADE, related_name="adjuntos"
    )
    tipo = models.CharField(max_length=30, blank=True)  # imagen/video/audio/otro
    ruta_archivo = models.FileField(upload_to="adjuntos/")
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created"]
        verbose_name = "Archivo adjunto"
        verbose_name_plural = "Archivos adjuntos"

    def __str__(self):
        return f"Adjunto {self.id} ({self.tipo or 'archivo'})"
