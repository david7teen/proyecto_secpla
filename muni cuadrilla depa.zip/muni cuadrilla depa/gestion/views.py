from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.db.models import Count
from .models import Cuadrilla
from .forms import CuadrillaForm, AsignarCuadrillaForm


# Modelos del módulo
from .models import (
    Direccion, Departamento, TipoIncidencia,
    Encuesta, Solicitud, Cuadrilla, ArchivoAdjunto
)

# Formularios
from .forms import (
    DireccionForm, DepartamentoForm, TipoIncidenciaForm
)
# --------- MAIN DEL MÓDULO ---------
@login_required
def main_gestion(request):
    return render(request, "gestion/main_gestion.html", {
        "titulo": "Gestión Municipal",
        "nota": "Direcciones, Departamentos, Tipos de Incidencia, Encuestas, Solicitudes y Cuadrillas."
    })


# --------- CRUD DIRECCIONES ---------
@login_required
def direccion_list(request):
    q = request.GET.get("q", "").strip()
    qs = Direccion.objects.all().order_by("nombre_direccion")
    if q:
        qs = qs.filter(nombre_direccion__icontains=q)
    return render(request, "gestion/direccion_list.html", {"items": qs, "q": q})


@login_required
def direccion_create(request):
    if request.method == "POST":
        form = DireccionForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "✅ Dirección creada correctamente.")
            return redirect("gestion_direccion_list")
        messages.error(request, "⚠ Corrige los errores del formulario.")
    else:
        form = DireccionForm()
    return render(request, "gestion/direccion_form.html", {"form": form, "modo": "crear"})


@login_required
def direccion_update(request, pk):
    obj = get_object_or_404(Direccion, pk=pk)
    if request.method == "POST":
        form = DireccionForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, "✏️ Dirección actualizada.")
            return redirect("gestion_direccion_list")
    else:
        form = DireccionForm(instance=obj)
    return render(request, "gestion/direccion_form.html", {"form": form, "modo": "editar", "obj": obj})


@login_required
def direccion_delete(request, pk):
    obj = get_object_or_404(Direccion, pk=pk)
    if request.method == "POST":
        obj.state = "Inactivo"   # Bloquear en lugar de eliminar físicamente
        obj.save()
        messages.success(request, "🗑️ Dirección bloqueada (Inactiva).")
        return redirect("gestion_direccion_list")
    return render(request, "gestion/direccion_confirm_delete.html", {"obj": obj})


@login_required
def direccion_detail(request, pk):
    obj = get_object_or_404(Direccion, pk=pk)
    return render(request, "gestion/direccion_detail.html", {"obj": obj})


# --------- CRUD DEPARTAMENTOS ---------
@login_required
def departamento_list(request):
    q = request.GET.get("q", "").strip()
    qs = Departamento.objects.select_related("direccion").order_by("nombre_departamento")
    if q:
        qs = qs.filter(nombre_departamento__icontains=q)
    return render(request, "gestion/departamento_list.html", {"items": qs, "q": q})


@login_required
def departamento_create(request):
    if request.method == "POST":
        form = DepartamentoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "✅ Departamento creado correctamente.")
            return redirect("gestion_departamento_list")
        messages.error(request, "⚠ Corrige los errores del formulario.")
    else:
        form = DepartamentoForm()
    return render(request, "gestion/departamento_form.html", {"form": form, "modo": "crear"})


@login_required
def departamento_update(request, pk):
    obj = get_object_or_404(Departamento, pk=pk)
    if request.method == "POST":
        form = DepartamentoForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, "✏️ Departamento actualizado.")
            return redirect("gestion_departamento_list")
    else:
        form = DepartamentoForm(instance=obj)
    return render(request, "gestion/departamento_form.html", {"form": form, "modo": "editar", "obj": obj})


@login_required
def departamento_delete(request, pk):
    obj = get_object_or_404(Departamento, pk=pk)
    if request.method == "POST":
        obj.state = "Inactivo"
        obj.save()
        messages.success(request, "🗑️ Departamento bloqueado (Inactivo).")
        return redirect("gestion_departamento_list")
    return render(request, "gestion/departamento_confirm_delete.html", {"obj": obj})


@login_required
def departamento_detail(request, pk):
    obj = get_object_or_404(Departamento, pk=pk)
    return render(request, "gestion/departamento_detail.html", {"obj": obj})


# --------- CRUD TIPOS DE INCIDENCIA ---------
@login_required
def tipo_list(request):
    q = request.GET.get("q", "").strip()
    qs = TipoIncidencia.objects.select_related("departamento").order_by("nombre")
    if q:
        qs = qs.filter(nombre__icontains=q)
    return render(request, "gestion/tipo_list.html", {"items": qs, "q": q})


@login_required
def tipo_create(request):
    if request.method == "POST":
        form = TipoIncidenciaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "✅ Tipo de Incidencia creado correctamente.")
            return redirect("gestion_tipo_list")
        messages.error(request, "⚠ Corrige los errores del formulario.")
    else:
        form = TipoIncidenciaForm()
    return render(request, "gestion/tipo_form.html", {"form": form, "modo": "crear"})


@login_required
def tipo_update(request, pk):
    obj = get_object_or_404(TipoIncidencia, pk=pk)
    if request.method == "POST":
        form = TipoIncidenciaForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, "✏️ Tipo de Incidencia actualizado.")
            return redirect("gestion_tipo_list")
    else:
        form = TipoIncidenciaForm(instance=obj)
    return render(request, "gestion/tipo_form.html", {"form": form, "modo": "editar", "obj": obj})


@login_required
def tipo_delete(request, pk):
    obj = get_object_or_404(TipoIncidencia, pk=pk)
    if request.method == "POST":
        obj.state = "Inactivo"
        obj.save()
        messages.success(request, "🗑️ Tipo de Incidencia bloqueado (Inactivo).")
        return redirect("gestion_tipo_list")
    return render(request, "gestion/tipo_confirm_delete.html", {"obj": obj})


@login_required
def tipo_detail(request, pk):
    obj = get_object_or_404(TipoIncidencia, pk=pk)
    return render(request, "gestion/tipo_detail.html", {"obj": obj})


# --------- OVERVIEW / RESUMEN GENERAL ---------
@login_required
def overview(request):
    """
    Resumen general del sistema:
    - Contadores por entidad
    - Últimos 5 registros de cada entidad
    - Ranking de Departamentos por cantidad de Tipos de Incidencia
    """
    counts = {
        "direcciones": Direccion.objects.count(),
        "departamentos": Departamento.objects.count(),
        "tipos": TipoIncidencia.objects.count(),
        "encuestas": Encuesta.objects.count(),
        "solicitudes": Solicitud.objects.count(),
        "cuadrillas": Cuadrilla.objects.count(),
        "adjuntos": ArchivoAdjunto.objects.count(),
    }

    ultimos = {
        "direcciones": Direccion.objects.order_by("-id")[:5],
        "departamentos": Departamento.objects.select_related("direccion").order_by("-id")[:5],
        "tipos": TipoIncidencia.objects.select_related("departamento").order_by("-id")[:5],
        "encuestas": Encuesta.objects.select_related("tipo_incidencia").order_by("-id")[:5],
        "solicitudes": Solicitud.objects.select_related("encuesta").order_by("-id")[:5],
        "cuadrillas": Cuadrilla.objects.select_related("departamento", "solicitud").order_by("-id")[:5],
        "adjuntos": ArchivoAdjunto.objects.select_related("solicitud").order_by("-id")[:5],
    }

    ranking_departamentos = (
        Departamento.objects.values("id", "nombre_departamento")
        .annotate(total_tipos=Count("tipos_incidencia"))
        .order_by("-total_tipos")[:5]
    )

    ctx = {
        "counts": counts,
        "ultimos": ultimos,
        "ranking_departamentos": ranking_departamentos,
    }
    return render(request, "gestion/overview.html", ctx)


def crear_cuadrilla(request):
    form = CuadrillaForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect("listar_cuadrillas")

    return render(request, "gestion/crear_cuadrilla.html", {"form": form})


def listar_cuadrillas(request):
    cuadrillas = Cuadrilla.objects.all()
    return render(request, "gestion/listar_cuadrillas.html", {"cuadrillas": cuadrillas})


def asignar_cuadrilla(request, id):
    cuadrilla = get_object_or_404(Cuadrilla, id=id)
    form = AsignarCuadrillaForm(request.POST or None, instance=cuadrilla)

    if form.is_valid():
        form.save()
        return redirect("listar_cuadrillas")

    return render(request, "gestion/asignar_cuadrilla.html", {"form": form, "cuadrilla": cuadrilla})

