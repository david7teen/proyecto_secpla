from django.urls import reverse
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from .forms import HabilidadForm, HeroeForm
from .models import Habilidad, Heroe


# ---------- MENÚ PRINCIPAL ----------
@login_required
def main_habilidad(request):
    """
    Vista principal del módulo de habilidades.
    Muestra un mensaje general y enlaces al CRUD.
    """
    return render(request, "heroes/main_habilidad.html", {
        "titulo": "Gestión de Habilidades",
        "nota": "Usa el menú para crear, listar, editar o eliminar habilidades."
    })


# ---------- CRUD DE HABILIDADES ----------
@login_required
def habilidad_list(request):
    """Lista todas las habilidades"""
    q = request.GET.get("q", "").strip()
    qs = Habilidad.objects.all().order_by("nombre")
    if q:
        qs = qs.filter(nombre__icontains=q)
    return render(request, "heroes/habilidad_list.html", {"items": qs, "q": q})


@login_required
def habilidad_create(request):
    """Formulario para crear una nueva habilidad"""
    if request.method == "POST":
        form = HabilidadForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "✅ Habilidad creada correctamente.")
            return redirect("heroes_habilidad_list")
        else:
            messages.error(request, "⚠ Error al crear la habilidad.")
    else:
        form = HabilidadForm()

    # Validación tipo Tutorial 4 (por si llega ?err=1 en la URL)
    if request.GET.get("err"):
        messages.warning(request, "⚠ Faltan datos: completa todos los campos.")

    return render(request, "heroes/habilidad_form.html", {"form": form, "modo": "crear"})


@login_required
def habilidad_guardar(request):
    """
    Versión simple de guardado manual (para compatibilidad con Tutorial 4).
    Guarda una nueva habilidad usando POST directo desde el formulario HTML.
    """
    if request.method == 'POST':
        nombre = request.POST.get('nombre', '').strip()
        descripcion = request.POST.get('descripcion', '').strip()

        # Validación manual si los campos vienen vacíos
        if nombre == '' or descripcion == '':
            return redirect(f"{reverse('habilidad_crear')}?err=1")

        # Crea y guarda la habilidad directamente
        h = Habilidad(nombre=nombre, descripcion=descripcion, state='Activo')
        h.save()

        messages.success(request, "✅ Habilidad guardada correctamente.")
        return redirect('heroes_main_habilidad')

    # Si alguien entra por GET, lo devolvemos al formulario
    return redirect('habilidad_crear')


@login_required
def habilidad_update(request, pk):
    """Editar una habilidad existente"""
    obj = get_object_or_404(Habilidad, pk=pk)
    if request.method == "POST":
        form = HabilidadForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, "✏️ Habilidad actualizada.")
            return redirect("heroes_habilidad_list")
    else:
        form = HabilidadForm(instance=obj)
    return render(request, "heroes/habilidad_form.html", {"form": form, "modo": "editar", "obj": obj})


@login_required
def habilidad_delete(request, pk):
    """Confirmar y eliminar una habilidad"""
    obj = get_object_or_404(Habilidad, pk=pk)
    if request.method == "POST":
        obj.delete()
        messages.success(request, "🗑️ Habilidad eliminada correctamente.")
        return redirect("heroes_habilidad_list")
    return render(request, "heroes/habilidad_confirm_delete.html", {"obj": obj})


@login_required
def habilidad_detail(request, pk):
    """Detalle de una habilidad"""
    obj = get_object_or_404(Habilidad, pk=pk)
    return render(request, "heroes/habilidad_detail.html", {"obj": obj})


# ---------- CRUD DE HÉROES ----------
@login_required
def heroe_list(request):
    """Lista de héroes"""
    q = request.GET.get("q", "").strip()
    qs = Heroe.objects.select_related("habilidad").order_by("nombre")
    if q:
        qs = qs.filter(nombre__icontains=q) | qs.filter(alias__icontains=q)
    return render(request, "heroes/heroe_list.html", {"items": qs, "q": q})


@login_required
def heroe_create(request):
    """Crear un nuevo héroe"""
    if request.method == "POST":
        form = HeroeForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "✅ Héroe creado correctamente.")
            return redirect("heroes_heroe_list")
        else:
            messages.error(request, "⚠ Error al crear el héroe.")
    else:
        form = HeroeForm()
    return render(request, "heroes/heroe_form.html", {"form": form, "modo": "crear"})


@login_required
def heroe_update(request, pk):
    """Editar héroe"""
    obj = get_object_or_404(Heroe, pk=pk)
    if request.method == "POST":
        form = HeroeForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, "✏️ Héroe actualizado correctamente.")
            return redirect("heroes_heroe_list")
    else:
        form = HeroeForm(instance=obj)
    return render(request, "heroes/heroe_form.html", {"form": form, "modo": "editar", "obj": obj})


@login_required
def heroe_delete(request, pk):
    """Eliminar héroe"""
    obj = get_object_or_404(Heroe, pk=pk)
    if request.method == "POST":
        obj.delete()
        messages.success(request, "🗑️ Héroe eliminado correctamente.")
        return redirect("heroes_heroe_list")
    return render(request, "heroes/heroe_confirm_delete.html", {"obj": obj})


@login_required
def heroe_detail(request, pk):
    """Ver detalle de un héroe"""
    obj = get_object_or_404(Heroe, pk=pk)
    return render(request, "heroes/heroe_detail.html", {"obj": obj})
