from django import forms
from .models import Habilidad, Heroe

class HabilidadForm(forms.ModelForm):
    class Meta:
        model = Habilidad
        fields = ["nombre", "descripcion", "state"]
        widgets = {
            "nombre": forms.TextInput(attrs={"class": "form-control"}),
            "descripcion": forms.Textarea(attrs={"rows": 3, "class": "form-control"}),
            "state": forms.Select(attrs={"class": "form-control"}),
        }

class HeroeForm(forms.ModelForm):
    # Solo muestra habilidades activas en el combo
    habilidad = forms.ModelChoiceField(
        queryset=Habilidad.objects.filter(state="Activo").order_by("nombre"),
        widget=forms.Select(attrs={"class": "form-control"})
    )

    class Meta:
        model = Heroe
        fields = ["nombre", "alias", "edad", "descripcion", "habilidad", "state"]
        widgets = {
            "nombre": forms.TextInput(attrs={"class": "form-control"}),
            "alias": forms.TextInput(attrs={"class": "form-control"}),
            "edad": forms.NumberInput(attrs={"class": "form-control"}),
            "descripcion": forms.Textarea(attrs={"rows": 3, "class": "form-control"}),
            "state": forms.Select(attrs={"class": "form-control"}),
        }
